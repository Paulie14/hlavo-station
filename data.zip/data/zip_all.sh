#!/bin/bash

# Iterate over each item in the current directory
for dir in */; do
  # Check if it is a directory
  if [ -d "$dir" ]; then
    # Remove trailing slash and create zip file with the directory name
    zip -r "${dir%/}.zip" "$dir"
  fi
done